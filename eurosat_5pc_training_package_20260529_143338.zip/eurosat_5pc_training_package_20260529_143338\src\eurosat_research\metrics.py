from __future__ import annotations

import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, precision_score, recall_score

from .constants import CLASSES


def compute_metrics(y_true, y_pred) -> dict:
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "macro_f1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "weighted_f1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
    }


def classwise_report(y_true, y_pred) -> pd.DataFrame:
    report = classification_report(y_true, y_pred, target_names=CLASSES, output_dict=True, zero_division=0)
    rows = []
    for class_name in CLASSES:
        rows.append(
            {
                "Land Cover Class": class_name,
                "Precision (%)": report[class_name]["precision"] * 100,
                "Recall (%)": report[class_name]["recall"] * 100,
                "F1-Score (%)": report[class_name]["f1-score"] * 100,
                "Number of Test Samples": report[class_name]["support"],
            }
        )
    return pd.DataFrame(rows)


def confusion_matrix_frame(y_true, y_pred) -> pd.DataFrame:
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(CLASSES))))
    return pd.DataFrame(cm, index=CLASSES, columns=CLASSES)

