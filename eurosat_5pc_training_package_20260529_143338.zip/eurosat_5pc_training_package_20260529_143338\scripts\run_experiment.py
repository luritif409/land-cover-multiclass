from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
import sys

import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from eurosat_research.constants import BAND_CHANNELS, CLASSES
from eurosat_research.data import EuroSATDataset, load_split_csv
from eurosat_research.metrics import classwise_report, compute_metrics, confusion_matrix_frame
from eurosat_research.models import count_parameters, create_model, estimate_flops_g
from eurosat_research.training import evaluate, measure_inference_time, train_one_epoch


def parse_args():
    parser = argparse.ArgumentParser(description="Run one EuroSAT experiment.")
    parser.add_argument("--experiment-id", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--model-type", default="")
    parser.add_argument("--input-bands", choices=sorted(BAND_CHANNELS), required=True)
    parser.add_argument("--input-size", type=int, required=True)
    parser.add_argument("--splits-dir", type=Path, default=Path("outputs/splits"))
    parser.add_argument("--dataset-dir", type=Path, default=None)
    parser.add_argument("--rgb-dataset-dir", type=Path, default=None)
    parser.add_argument("--multispectral-dataset-dir", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--no-pretrained", action="store_true")
    return parser.parse_args()


def append_result(results_path: Path, row: dict) -> None:
    df = pd.DataFrame([row])
    if results_path.exists():
        existing = pd.read_csv(results_path)
        existing = existing[existing["experiment_id"] != row["experiment_id"]]
        df = pd.concat([existing, df], ignore_index=True)
    try:
        df.to_csv(results_path, index=False)
    except PermissionError:
        fallback = results_path.with_name(f"{results_path.stem}_new{results_path.suffix}")
        df.to_csv(fallback, index=False)
        print(f"Locked: {results_path}; saved {fallback}")


def main():
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "checkpoints").mkdir(parents=True, exist_ok=True)
    (args.output_dir / "tables").mkdir(parents=True, exist_ok=True)

    dataset_dir = args.dataset_dir
    if dataset_dir is None:
        dataset_dir = args.rgb_dataset_dir if args.input_bands == "rgb" else args.multispectral_dataset_dir
    if dataset_dir is None:
        train_df = pd.read_csv(args.splits_dir / "train.csv")
        val_df = pd.read_csv(args.splits_dir / "val.csv")
        test_df = pd.read_csv(args.splits_dir / "test.csv")
    else:
        val_name = "validation.csv" if (args.splits_dir / "validation.csv").exists() else "val.csv"
        train_df = load_split_csv(args.splits_dir / "train.csv", dataset_dir)
        val_df = load_split_csv(args.splits_dir / val_name, dataset_dir)
        test_df = load_split_csv(args.splits_dir / "test.csv", dataset_dir)

    train_loader = DataLoader(
        EuroSATDataset(train_df, args.input_bands, args.input_size, train=True),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
    )
    val_loader = DataLoader(
        EuroSATDataset(val_df, args.input_bands, args.input_size),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
    )
    test_loader = DataLoader(
        EuroSATDataset(test_df, args.input_bands, args.input_size),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    in_channels = BAND_CHANNELS[args.input_bands]
    model = create_model(
        args.model,
        len(CLASSES),
        in_channels,
        pretrained=not args.no_pretrained,
        input_size=args.input_size,
    ).to(device)
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)

    best_val_f1 = -1.0
    best_path = args.output_dir / "checkpoints" / f"{args.experiment_id}.pt"
    epoch_times = []

    for epoch in range(1, args.epochs + 1):
        start = time.time()
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc, y_val, y_val_pred = evaluate(model, val_loader, criterion, device)
        epoch_time = time.time() - start
        epoch_times.append(epoch_time)
        val_metrics = compute_metrics(y_val, y_val_pred)

        print(
            f"Epoch {epoch:03d}/{args.epochs} "
            f"train_loss={train_loss:.4f} train_acc={train_acc:.4f} "
            f"val_loss={val_loss:.4f} val_acc={val_acc:.4f} val_macro_f1={val_metrics['macro_f1']:.4f}"
        )

        if val_metrics["macro_f1"] > best_val_f1:
            best_val_f1 = val_metrics["macro_f1"]
            torch.save(model.state_dict(), best_path)

    model.load_state_dict(torch.load(best_path, map_location=device))
    test_loss, test_acc, y_true, y_pred = evaluate(model, test_loader, criterion, device)
    metrics = compute_metrics(y_true, y_pred)

    params_m = count_parameters(model)
    flops_g = estimate_flops_g(model, in_channels, args.input_size, device)
    inference_time = measure_inference_time(model, test_loader, device)
    gpu_memory = None
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
        dummy = torch.randn(1, in_channels, args.input_size, args.input_size, device=device)
        _ = model(dummy)
        gpu_memory = torch.cuda.max_memory_allocated() / 1024**2

    result = {
        "experiment_id": args.experiment_id,
        "model": args.model,
        "model_type": args.model_type,
        "input_bands": args.input_bands,
        "input_size": args.input_size,
        "loss_function": "CrossEntropy",
        "training_strategy": "Standard",
        "accuracy": metrics["accuracy"] * 100,
        "precision": metrics["precision"] * 100,
        "recall": metrics["recall"] * 100,
        "macro_f1": metrics["macro_f1"] * 100,
        "weighted_f1": metrics["weighted_f1"] * 100,
        "parameters_m": params_m,
        "flops_g": flops_g,
        "training_time_epoch": sum(epoch_times) / len(epoch_times) / 60,
        "total_training_time": sum(epoch_times) / 60,
        "inference_time_image": inference_time,
        "gpu_memory": gpu_memory,
        "checkpoint": str(best_path),
    }

    append_result(args.output_dir / "results.csv", result)
    classwise_report(y_true, y_pred).to_csv(args.output_dir / "tables" / f"{args.experiment_id}_classwise.csv", index=False)
    confusion_matrix_frame(y_true, y_pred).to_csv(args.output_dir / "tables" / f"{args.experiment_id}_confusion_matrix.csv")

    with open(args.output_dir / f"{args.experiment_id}_predictions.json", "w", encoding="utf-8") as f:
        json.dump({"y_true": y_true, "y_pred": y_pred}, f)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
