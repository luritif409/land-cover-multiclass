from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import pandas as pd


def parse_args():
    parser = argparse.ArgumentParser(description="Run experiments listed in a CSV plan.")
    parser.add_argument("--plan", type=Path, default=Path("configs/experiments_minimal.csv"))
    parser.add_argument("--splits-dir", type=Path, default=Path("outputs/splits"))
    parser.add_argument("--rgb-splits-dir", type=Path, default=None)
    parser.add_argument("--multispectral-splits-dir", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--rgb-dataset-dir", type=Path, default=None)
    parser.add_argument("--multispectral-dataset-dir", type=Path, default=None)
    parser.add_argument("--start-from", default=None, help="Optional experiment_id to resume from.")
    parser.add_argument("--no-pretrained", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    plan = pd.read_csv(args.plan)
    if args.start_from:
        start_idx = plan.index[plan["experiment_id"] == args.start_from]
        if len(start_idx) == 0:
            raise ValueError(f"experiment_id tidak ditemukan: {args.start_from}")
        plan = plan.loc[start_idx[0] :]

    for _, row in plan.iterrows():
        input_bands = str(row["input_bands"])
        splits_dir = args.splits_dir
        if input_bands == "rgb" and args.rgb_splits_dir:
            splits_dir = args.rgb_splits_dir
        if input_bands != "rgb" and args.multispectral_splits_dir:
            splits_dir = args.multispectral_splits_dir
        command = [
            sys.executable,
            "scripts/run_experiment.py",
            "--experiment-id",
            str(row["experiment_id"]),
            "--model",
            str(row["model"]),
            "--model-type",
            str(row["model_type"]),
            "--input-bands",
            input_bands,
            "--input-size",
            str(int(row["input_size"])),
            "--epochs",
            str(int(row["epochs"])),
            "--batch-size",
            str(int(row["batch_size"])),
            "--splits-dir",
            str(splits_dir),
            "--output-dir",
            str(args.output_dir),
        ]
        if args.rgb_dataset_dir:
            command.extend(["--rgb-dataset-dir", str(args.rgb_dataset_dir)])
        if args.multispectral_dataset_dir:
            command.extend(["--multispectral-dataset-dir", str(args.multispectral_dataset_dir)])
        if args.no_pretrained:
            command.append("--no-pretrained")
        print("Running:", " ".join(command), flush=True)
        subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
