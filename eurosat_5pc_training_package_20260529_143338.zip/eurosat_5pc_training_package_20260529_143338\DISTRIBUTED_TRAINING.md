# Distributed CPU Training Plan

Gunakan 5 PC untuk menjalankan eksperimen berbeda. Semua eksperimen tetap `20` epoch.

## Pembagian

```text
PC 1: configs/pc1_resnet50_remaining.csv
PC 2: configs/pc2_efficientnet_b0.csv
PC 3: configs/pc3_densenet121.csv
PC 4: configs/pc4_vit_base.csv
PC 5: configs/pc5_swin_tiny.csv
```

PC 1 memakai `remaining` karena EXP001 sampai EXP005 sudah selesai.

## Command

Ganti nama config sesuai PC masing-masing:

```bash
python scripts/run_plan.py ^
  --plan configs/pc1_resnet50_remaining.csv ^
  --rgb-splits-dir outputs/splits_rgb ^
  --multispectral-splits-dir outputs/splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

## Setelah Selesai

Kumpulkan dari semua PC:

```text
outputs/results.csv
outputs/tables/*_classwise.csv
outputs/tables/*_confusion_matrix.csv
outputs/checkpoints/*.pt
```

Gabungkan semua baris `results.csv` ke satu file master, lalu jalankan:

```bash
python scripts/build_tables.py --results outputs/results_merged.csv --output-dir outputs/tables
```
