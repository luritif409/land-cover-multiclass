CLASSES = [
    "AnnualCrop",
    "Forest",
    "HerbaceousVegetation",
    "Highway",
    "Industrial",
    "Pasture",
    "PermanentCrop",
    "Residential",
    "River",
    "SeaLake",
]

MODEL_ALIASES = {
    "ResNet-50": "resnet50",
    "EfficientNet-B0": "efficientnet_b0",
    "DenseNet-121": "densenet121",
    "ViT-Base": "vit_base_patch16_224",
    "Swin-Tiny": "swin_tiny_patch4_window7_224",
}

MODEL_TYPES = {
    "resnet50": "CNN",
    "efficientnet_b0": "CNN",
    "densenet121": "CNN",
    "vit_base_patch16_224": "Transformer",
    "swin_tiny_patch4_window7_224": "Transformer",
}

BAND_CHANNELS = {
    "rgb": 3,
    "rgb_nir": 4,
    "10m": 4,
    "13bands": 13,
    "13bands_indices": 16,
}

