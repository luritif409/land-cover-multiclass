from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def parse_args():
    parser = argparse.ArgumentParser(description="Build paper tables from experiment results.")
    parser.add_argument("--results", type=Path, default=Path("outputs/results.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/tables"))
    return parser.parse_args()


def save(df: pd.DataFrame, path: Path):
    try:
        df.to_csv(path, index=False)
        print(f"Saved {path}")
    except PermissionError:
        fallback = path.with_name(f"{path.stem}_new{path.suffix}")
        df.to_csv(fallback, index=False)
        print(f"Locked: {path}; saved {fallback}")


def main():
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    results = pd.read_csv(args.results)
    results = results[~results["experiment_id"].astype(str).str.contains("CPUCHECK", case=False, na=False)].copy()

    table2 = results[(results["model"] == "resnet50") & (results["input_size"] == 64)].copy()
    save(table2, args.output_dir / "table2_baseline_model_performance.csv")

    table5 = results[
        (results["input_bands"].isin(["rgb", "13bands"])) & (results["input_size"] == 224)
    ].copy()
    save(table5, args.output_dir / "table5_cnn_vs_transformer.csv")

    table6 = results[results["input_size"] == 224].pivot_table(
        index="model",
        columns="input_bands",
        values="macro_f1",
        aggfunc="max",
    ).reset_index()
    band_columns = [col for col in table6.columns if col != "model"]
    table6["best_configuration"] = table6[band_columns].idxmax(axis=1)
    save(table6, args.output_dir / "table6_band_configuration_ablation.csv")

    table7 = results[results["input_bands"].isin(["rgb", "13bands"])].pivot_table(
        index=["model", "input_bands"],
        columns="input_size",
        values="macro_f1",
        aggfunc="max",
    ).reset_index()
    resolution_columns = [col for col in table7.columns if isinstance(col, int)]
    if resolution_columns:
        table7["best_resolution"] = table7[resolution_columns].idxmax(axis=1)
    save(table7, args.output_dir / "table7_input_resolution_ablation.csv")

    table13 = results[
        [
            "model",
            "input_bands",
            "input_size",
            "parameters_m",
            "flops_g",
            "training_time_epoch",
            "total_training_time",
            "inference_time_image",
            "gpu_memory",
        ]
    ].copy()
    save(table13, args.output_dir / "table13_computational_efficiency.csv")

    table14 = results.sort_values("macro_f1", ascending=False).head(5).copy()
    table14.insert(0, "rank", range(1, len(table14) + 1))
    save(table14, args.output_dir / "table14_best_configurations.csv")

    best_overall = results.sort_values("macro_f1", ascending=False).iloc[0]
    best_cnn = results[results["model_type"].str.lower() == "cnn"].sort_values("macro_f1", ascending=False).head(1)
    best_transformer = results[results["model_type"].str.lower() == "transformer"].sort_values("macro_f1", ascending=False).head(1)

    if not best_cnn.empty:
        exp_id = best_cnn.iloc[0]["experiment_id"]
        source = args.output_dir / f"{exp_id}_classwise.csv"
        if not source.exists():
            source = args.output_dir / "tables" / f"{exp_id}_classwise.csv"
        if source.exists():
            table10 = pd.read_csv(source)
            save(table10, args.output_dir / "table10_best_cnn_classwise.csv")

    if not best_transformer.empty:
        exp_id = best_transformer.iloc[0]["experiment_id"]
        source = args.output_dir / f"{exp_id}_classwise.csv"
        if not source.exists():
            source = args.output_dir / "tables" / f"{exp_id}_classwise.csv"
        if source.exists():
            table11 = pd.read_csv(source)
            save(table11, args.output_dir / "table11_best_transformer_classwise.csv")

    cm_source = args.output_dir / f"{best_overall['experiment_id']}_confusion_matrix.csv"
    if not cm_source.exists():
        cm_source = args.output_dir / "tables" / f"{best_overall['experiment_id']}_confusion_matrix.csv"
    if cm_source.exists():
        table12 = pd.read_csv(cm_source)
        table12.to_csv(args.output_dir / "table12_best_overall_confusion_matrix.csv", index=False)
        print(f"Saved {args.output_dir / 'table12_best_overall_confusion_matrix.csv'}")

    print("Best overall experiment:", best_overall["experiment_id"])


if __name__ == "__main__":
    main()
