from __future__ import annotations

import timm
import torch


def create_model(
    model_name: str,
    num_classes: int,
    in_channels: int,
    pretrained: bool = True,
    input_size: int | None = None,
):
    kwargs = {}
    if input_size is not None and (model_name.startswith("vit_") or model_name.startswith("swin_")):
        kwargs["img_size"] = input_size
    return timm.create_model(
        model_name,
        pretrained=pretrained,
        num_classes=num_classes,
        in_chans=in_channels,
        **kwargs,
    )


def count_parameters(model: torch.nn.Module) -> float:
    return sum(p.numel() for p in model.parameters()) / 1e6


def estimate_flops_g(model: torch.nn.Module, in_channels: int, input_size: int, device: torch.device) -> float | None:
    try:
        from thop import profile
    except ImportError:
        return None

    was_training = model.training
    model.eval()
    dummy = torch.randn(1, in_channels, input_size, input_size, device=device)
    flops, _ = profile(model, inputs=(dummy,), verbose=False)
    if was_training:
        model.train()
    return flops / 1e9
