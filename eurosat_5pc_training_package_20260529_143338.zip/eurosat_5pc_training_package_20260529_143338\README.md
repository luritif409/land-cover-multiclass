# EuroSAT Cross-Model Land Cover Research

Project ini dibuat untuk eksperimen:

**Cross-Model Evaluation of CNN and Vision Transformer for Multi-Class Land Cover Classification Using Sentinel-2 Multispectral Imagery**

Dataset rujukan: https://www.kaggle.com/datasets/apollo2506/eurosat-dataset

## Struktur

```text
.
├── configs/
│   ├── experiments_full.csv
│   └── experiments_minimal.csv
├── data/
│   └── .gitkeep
├── outputs/
│   ├── checkpoints/
│   ├── splits/
│   └── tables/
├── scripts/
│   ├── prepare_splits.py
│   ├── run_plan.py
│   ├── run_experiment.py
│   └── build_tables.py
├── src/
│   └── eurosat_research/
└── requirements.txt
```

## Instalasi

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Dataset

Letakkan dataset di folder seperti ini:

```text
data/dataset/
├── AnnualCrop/
├── Forest/
├── HerbaceousVegetation/
├── Highway/
├── Industrial/
├── Pasture/
├── PermanentCrop/
├── Residential/
├── River/
└── SeaLake/
```

File dapat berupa citra RGB umum (`.jpg`, `.png`) atau multispectral Sentinel-2 (`.tif`, `.tiff`).

## 1. Buat Split Dataset

```bash
python scripts/prepare_splits.py --dataset-dir data/dataset --output-dir outputs/splits
```

Output:

- `outputs/splits/table1_dataset_distribution.csv`
- `outputs/splits/train.csv`
- `outputs/splits/val.csv`
- `outputs/splits/test.csv`

## 2. Jalankan Satu Eksperimen

Contoh baseline:

```bash
python scripts/run_experiment.py ^
  --experiment-id EXP001 ^
  --model resnet50 ^
  --model-type CNN ^
  --input-bands rgb ^
  --input-size 64 ^
  --epochs 20 ^
  --batch-size 32 ^
  --splits-dir outputs/splits ^
  --output-dir outputs
```

Untuk eksperimen banyak, gunakan daftar di `configs/experiments_minimal.csv` atau `configs/experiments_full.csv` sebagai antrean kerja.

Menjalankan batch minimal:

```bash
python scripts/run_plan.py --plan configs/experiments_minimal.csv
```

Jika RGB dan multispectral disimpan di folder berbeda:

```bash
python scripts/run_plan.py ^
  --plan configs/experiments_minimal.csv ^
  --rgb-splits-dir outputs/splits_rgb ^
  --multispectral-splits-dir outputs/splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

Melanjutkan dari eksperimen tertentu:

```bash
python scripts/run_plan.py --plan configs/experiments_full.csv --start-from EXP020
```

## 3. Bangun Tabel Paper

Setelah beberapa eksperimen selesai:

```bash
python scripts/build_tables.py --results outputs/results.csv --output-dir outputs/tables
```

Output tabel:

- Table 2 baseline performance
- Table 5 CNN vs Transformer comparison
- Table 6 band configuration ablation
- Table 7 input resolution ablation
- Table 10 best CNN class-wise performance
- Table 11 best Transformer class-wise performance
- Table 12 confusion matrix best overall model
- Table 13 computational efficiency
- Table 14 top-5 best configurations

## Catatan Penting

- Untuk GPU terbatas, mulai dari `configs/experiments_minimal.csv`.
- Gunakan `macro_f1` sebagai metrik utama pemilihan model terbaik.
- Untuk input multispectral, band mengikuti indeks zero-based rasterio:
  - RGB: B4, B3, B2
  - RGB + NIR: B4, B3, B2, B8
  - 10 m bands: B2, B3, B4, B8
  - 13 bands: semua band
  - 13 bands + indices: semua band + NDVI, NDWI, NDBI
