from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from eurosat_research.data import make_distribution_table, scan_dataset, stratified_split


def parse_args():
    parser = argparse.ArgumentParser(description="Create stratified EuroSAT train/val/test splits.")
    parser.add_argument("--dataset-dir", type=Path, default=Path("data/dataset"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/splits"))
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main():
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    df = scan_dataset(args.dataset_dir)
    table1 = make_distribution_table(df)
    train_df, val_df, test_df = stratified_split(df, seed=args.seed)

    table1.to_csv(args.output_dir / "table1_dataset_distribution.csv", index=False)
    train_df.to_csv(args.output_dir / "train.csv", index=False)
    val_df.to_csv(args.output_dir / "val.csv", index=False)
    test_df.to_csv(args.output_dir / "test.csv", index=False)

    print(f"Total images: {len(df)}")
    print(f"Train/Val/Test: {len(train_df)}/{len(val_df)}/{len(test_df)}")
    print(f"Saved to: {args.output_dir}")


if __name__ == "__main__":
    main()

