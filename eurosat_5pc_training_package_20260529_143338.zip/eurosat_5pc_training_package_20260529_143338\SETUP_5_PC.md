# Setup Eksperimen di 5 PC

Dokumen ini menjelaskan cara menjalankan eksperimen terdistribusi di 5 PC.

## 1. Struktur yang Harus Sama di Setiap PC

Setiap PC sebaiknya memiliki folder project dan dataset dengan struktur yang sama:

```text
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\
├── Lib\
├── Scripts\
├── src\
│   └── datasets\
│       ├── EuroSATrgb\
│       └── EuroSATallBands\
```

Project eksperimen ini berada di:

```text
C:\Users\angga\Documents\Codex\2026-05-28\files-mentioned-by-the-user-step
```

Copy folder project ini ke setiap PC, atau simpan di lokasi yang sama agar command di bawah bisa langsung dipakai.

## 2. File Penting yang Wajib Ada

Pastikan file/folder berikut ada di setiap PC:

```text
configs/
scripts/
src/
outputs/splits_rgb/
outputs/splits_allbands/
requirements.txt
```

Split dataset sudah dibuat 70/15/15. Jika belum ada di PC lain, copy folder berikut:

```text
outputs/splits_rgb
outputs/splits_allbands
```

## 3. Virtual Environment

Gunakan Python dari virtual environment yang sudah ada:

```text
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe
```

Cek library:

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe -c "import torch, timm, rasterio, sklearn, pandas; print('OK')"
```

## 4. Pembagian Eksperimen

```text
PC 1: ResNet-50
PC 2: EfficientNet-B0
PC 3: DenseNet-121
PC 4: ViT-Base
PC 5: Swin-Tiny
```

File config:

```text
PC 1: configs/pc1_resnet50_remaining.csv
PC 2: configs/pc2_efficientnet_b0.csv
PC 3: configs/pc3_densenet121.csv
PC 4: configs/pc4_vit_base.csv
PC 5: configs/pc5_swin_tiny.csv
```

Catatan: PC 1 menggunakan `remaining` karena EXP001 sampai EXP005 sudah selesai dan tetap digunakan untuk Table 2.

## 5. Command Per PC

Jalankan command dari folder project:

```bash
cd C:\Users\angga\Documents\Codex\2026-05-28\files-mentioned-by-the-user-step
```

### PC 1 - ResNet-50

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\run_plan.py ^
  --plan configs\pc1_resnet50_remaining.csv ^
  --rgb-splits-dir outputs\splits_rgb ^
  --multispectral-splits-dir outputs\splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

### PC 2 - EfficientNet-B0

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\run_plan.py ^
  --plan configs\pc2_efficientnet_b0.csv ^
  --rgb-splits-dir outputs\splits_rgb ^
  --multispectral-splits-dir outputs\splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

### PC 3 - DenseNet-121

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\run_plan.py ^
  --plan configs\pc3_densenet121.csv ^
  --rgb-splits-dir outputs\splits_rgb ^
  --multispectral-splits-dir outputs\splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

### PC 4 - ViT-Base

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\run_plan.py ^
  --plan configs\pc4_vit_base.csv ^
  --rgb-splits-dir outputs\splits_rgb ^
  --multispectral-splits-dir outputs\splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

### PC 5 - Swin-Tiny

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\run_plan.py ^
  --plan configs\pc5_swin_tiny.csv ^
  --rgb-splits-dir outputs\splits_rgb ^
  --multispectral-splits-dir outputs\splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

## 6. Resume Jika Terhenti

Jika PC mati atau proses berhenti, lihat eksperimen terakhir yang sudah masuk:

```bash
type outputs\results.csv
```

Lanjutkan dari eksperimen tertentu:

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\run_plan.py ^
  --plan configs\pc2_efficientnet_b0.csv ^
  --start-from EXP022 ^
  --rgb-splits-dir outputs\splits_rgb ^
  --multispectral-splits-dir outputs\splits_allbands ^
  --rgb-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATrgb ^
  --multispectral-dataset-dir E:\LAB_RESEARCH\code\land-cover-multiclass-classification\src\datasets\EuroSATallBands ^
  --no-pretrained
```

Ganti `EXP022` sesuai eksperimen pertama yang belum selesai.

## 7. Output yang Dikumpulkan

Setelah setiap PC selesai, kumpulkan file berikut dari masing-masing PC:

```text
outputs/results.csv
outputs/tables/*_classwise.csv
outputs/tables/*_confusion_matrix.csv
outputs/checkpoints/*.pt
```

Simpan ke PC utama dalam folder terpisah, misalnya:

```text
collected_results/
├── pc1/
├── pc2/
├── pc3/
├── pc4/
└── pc5/
```

## 8. Gabungkan Results CSV

Di PC utama, gabungkan semua `results.csv` menjadi satu file `outputs/results_merged.csv`.

Pastikan tidak ada duplikasi `experiment_id`. Jika ada, gunakan hasil terbaru atau hasil yang memang valid.

Setelah `results_merged.csv` siap:

```bash
E:\LAB_RESEARCH\code\land-cover-multiclass-classification\Scripts\python.exe scripts\build_tables.py ^
  --results outputs\results_merged.csv ^
  --output-dir outputs\tables
```

## 9. Catatan Penting

- Jangan buka `outputs/results.csv` di Excel saat training masih berjalan, karena bisa mengunci file dan membuat proses gagal menulis hasil.
- Semua eksperimen menggunakan `20` epoch.
- Semua command memakai `--no-pretrained`, sesuai eksperimen yang sudah berjalan.
- Jika ingin memakai pretrained model, hapus `--no-pretrained`, tetapi hasilnya tidak sebanding dengan eksperimen yang sudah dijalankan.
- Untuk menjaga konsistensi paper, gunakan dataset dan split yang sama di semua PC.
