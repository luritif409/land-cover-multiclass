from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from eurosat_research.constants import BAND_CHANNELS, CLASSES
from eurosat_research.data import EuroSATDataset, load_split_csv
from eurosat_research.metrics import classwise_report, compute_metrics, confusion_matrix_frame
from eurosat_research.models import count_parameters, create_model, estimate_flops_g
from eurosat_research.training import evaluate, measure_inference_time
from run_experiment import append_result


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate a saved experiment checkpoint.")
    parser.add_argument("--experiment-id", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--model-type", default="")
    parser.add_argument("--input-bands", choices=sorted(BAND_CHANNELS), required=True)
    parser.add_argument("--input-size", type=int, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--splits-dir", type=Path, required=True)
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=0)
    return parser.parse_args()


def main():
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "tables").mkdir(parents=True, exist_ok=True)

    test_df = load_split_csv(args.splits_dir / "test.csv", args.dataset_dir)
    test_loader = DataLoader(
        EuroSATDataset(test_df, args.input_bands, args.input_size),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    in_channels = BAND_CHANNELS[args.input_bands]
    model = create_model(
        args.model,
        len(CLASSES),
        in_channels,
        pretrained=False,
        input_size=args.input_size,
    ).to(device)
    model.load_state_dict(torch.load(args.checkpoint, map_location=device))
    criterion = torch.nn.CrossEntropyLoss()

    _, _, y_true, y_pred = evaluate(model, test_loader, criterion, device)
    metrics = compute_metrics(y_true, y_pred)
    params_m = count_parameters(model)
    flops_g = estimate_flops_g(model, in_channels, args.input_size, device)
    inference_time = measure_inference_time(model, test_loader, device)

    result = {
        "experiment_id": args.experiment_id,
        "model": args.model,
        "model_type": args.model_type,
        "input_bands": args.input_bands,
        "input_size": args.input_size,
        "loss_function": "CrossEntropy",
        "training_strategy": "Standard",
        "accuracy": metrics["accuracy"] * 100,
        "precision": metrics["precision"] * 100,
        "recall": metrics["recall"] * 100,
        "macro_f1": metrics["macro_f1"] * 100,
        "weighted_f1": metrics["weighted_f1"] * 100,
        "parameters_m": params_m,
        "flops_g": flops_g,
        "training_time_epoch": None,
        "total_training_time": None,
        "inference_time_image": inference_time,
        "gpu_memory": None,
        "checkpoint": str(args.checkpoint),
    }

    append_result(args.output_dir / "results.csv", result)
    classwise_report(y_true, y_pred).to_csv(args.output_dir / "tables" / f"{args.experiment_id}_classwise.csv", index=False)
    confusion_matrix_frame(y_true, y_pred).to_csv(args.output_dir / "tables" / f"{args.experiment_id}_confusion_matrix.csv")
    with open(args.output_dir / f"{args.experiment_id}_predictions.json", "w", encoding="utf-8") as f:
        json.dump({"y_true": y_true, "y_pred": y_pred}, f)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
