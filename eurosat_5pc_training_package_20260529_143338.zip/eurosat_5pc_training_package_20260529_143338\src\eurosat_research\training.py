from __future__ import annotations

import time

import torch
from tqdm import tqdm


def train_one_epoch(model, dataloader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for images, labels in tqdm(dataloader, desc="train", leave=False):
        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad(set_to_none=True)
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
        preds = outputs.argmax(dim=1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)

    return running_loss / total, correct / total


def evaluate(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    all_labels = []
    all_preds = []

    with torch.no_grad():
        for images, labels in tqdm(dataloader, desc="eval", leave=False):
            images = images.to(device)
            labels = labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)

            running_loss += loss.item() * images.size(0)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
            all_labels.extend(labels.cpu().numpy().tolist())
            all_preds.extend(preds.cpu().numpy().tolist())

    return running_loss / total, correct / total, all_labels, all_preds


def measure_inference_time(model, dataloader, device):
    model.eval()
    total_time = 0.0
    total_images = 0

    with torch.no_grad():
        for images, _ in tqdm(dataloader, desc="inference", leave=False):
            images = images.to(device)
            if device.type == "cuda":
                torch.cuda.synchronize()
            start = time.time()
            _ = model(images)
            if device.type == "cuda":
                torch.cuda.synchronize()
            total_time += time.time() - start
            total_images += images.size(0)

    return total_time / max(total_images, 1)

