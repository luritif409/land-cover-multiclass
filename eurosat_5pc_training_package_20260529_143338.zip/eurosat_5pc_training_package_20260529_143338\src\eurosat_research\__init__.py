"""Utilities for EuroSAT land-cover classification experiments."""

